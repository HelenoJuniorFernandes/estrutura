public class Fila<T> {
    private Node<T> inicio;
    private Node<T> fim;

    public void enqueue(T data) {
        Node<T> newNode = new Node<>(data);
        if (fim != null) {
            fim.next = newNode;
        }
        fim = newNode;
        if (inicio == null) {
            inicio = fim;
        }
    }

    public T dequeue() {
        if (isEmpty()) throw new RuntimeException("Fila vazia");
        T data = inicio.data;
        inicio = inicio.next;
        if (inicio == null) {
            fim = null;
        }
        return data;
    }

    public boolean isEmpty() {
        return inicio == null;
    }
}
