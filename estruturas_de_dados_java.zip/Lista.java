public class Lista<T> {
    private Node<T> cabeca;

    public void add(T data) {
        if (cabeca == null) {
            cabeca = new Node<>(data);
            return;
        }
        Node<T> atual = cabeca;
        while (atual.next != null) {
            atual = atual.next;
        }
        atual.next = new Node<>(data);
    }

    public void remove(T data) {
        if (cabeca == null) return;
        
        if (cabeca.data.equals(data)) {
            cabeca = cabeca.next;
            return;
        }

        Node<T> atual = cabeca;
        while (atual.next != null) {
            if (atual.next.data.equals(data)) {
                atual.next = atual.next.next;
                return;
            }
            atual = atual.next;
        }
    }

    public void print() {
        Node<T> atual = cabeca;
        while (atual != null) {
            System.out.print(atual.data + " -> ");
            atual = atual.next;
        }
        System.out.println("null");
    }
}
