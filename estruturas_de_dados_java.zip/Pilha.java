public class Pilha<T> {
    private Node<T> topo;

    public void push(T data) {
        Node<T> newNode = new Node<>(data);
        newNode.next = topo;
        topo = newNode;
    }

    public T pop() {
        if (isEmpty()) throw new RuntimeException("Pilha vazia");
        T data = topo.data;
        topo = topo.next;
        return data;
    }

    public T peek() {
        if (isEmpty()) throw new RuntimeException("Pilha vazia");
        return topo.data;
    }

    public boolean isEmpty() {
        return topo == null;
    }
}
